let score = JSON.parse(localStorage.getItem("score"));

if (score === null) {
  score = {
    wins: 0,
    losses: 0,
    ties: 0,
  };
}

function playGame(playerMove) {
  const computerMove = pickComputerMove();
  let result;

  //compare moves to get the result
  if (playerMove === computerMove) {
    result = "Tie";
    score.ties += 1;
  } else if (
    (playerMove === "rock" && computerMove === "scissors") ||
    (playerMove === "paper" && computerMove === "rock") ||
    (playerMove === "scissors" && computerMove === "paper")
  ) {
    result = "You win";
    score.wins = score.wins + 1;
  } else {
    result = "You lose";
    score.losses += 1;
  }

  localStorage.setItem("score", JSON.stringify(score));

  alert(
    `You picked ${playerMove}. Computer picked ${computerMove}. ${result}
Wins: ${score.wins}, Losses: ${score.losses}, Ties: ${score.ties}`
  );
}

function pickComputerMove() {
  const randomNumber = Math.random() * 3;
  let computerMove;
  if (randomNumber < 1) {
    computerMove = "rock";
  } else if (randomNumber < 2) {
    computerMove = "paper";
  } else {
    computerMove = "scissors";
  }
  return computerMove;
}

function resetScore() {
  score.wins = 0;
  score.losses = 0;
  score.ties = 0;
  localStorage.removeItem("score");
  alert(` Score hase been reseted.
Wins: ${score.wins}, Losses: ${score.losses}, Ties: ${score.ties}`);
}
