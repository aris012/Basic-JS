/*
steps:
when we refresh page
1. generate a random number 1-6
2. change the img based on the random number
3. compare the dice faces, give a result
4. display the result on the page
*/

function playGame() {
  const randomNumber1 = Math.floor(Math.random() * 6) + 1; // generate a random number 1-6
  const randomNumber2 = Math.floor(Math.random() * 6) + 1;

  const img1Element = document.querySelector(".img1");
  const img2Element = document.querySelector(".img2");
  const h1Element = document.querySelector("h1");

  img1Element.setAttribute("src", `images/dice${randomNumber1}.png`);
  img2Element.setAttribute("src", `images/dice${randomNumber2}.png`);

  let result;
  if (randomNumber1 > randomNumber2) {
    result = "🚩Player 1 wins";
  } else if (randomNumber1 < randomNumber2) {
    result = "Player 2 wins🚩";
  } else {
    result = "Draw";
  }

  h1Element.textContent = result;
}

const buttonElement = document.querySelector(".play-btn");

buttonElement.addEventListener("click", playGame);
